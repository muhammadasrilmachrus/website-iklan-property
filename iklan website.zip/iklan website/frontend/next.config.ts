import type { NextConfig } from "next";

const backendUrl = process.env.BACKEND_URL || "http://127.0.0.1:4000";

const nextConfig: NextConfig = {
  allowedDevOrigins: ["*.apps.tampilkit.com"],
  async rewrites() {
    return [{ source: "/api/:path*", destination: backendUrl + "/:path*" }];
  },
};

export default nextConfig;
